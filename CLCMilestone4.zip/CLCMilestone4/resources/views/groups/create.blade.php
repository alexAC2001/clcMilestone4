<?php 
// Alexander Carrillo & Jeanna Benitez

// CST - 256

// January 24th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.w3schools.com/css/tryit.asp?filename=trycss3_gradient-linear
// https://www.tutorialspoint.com/How-to-set-Text-alignment-in-HTML#:~:text=To%20set%20text%20alignment%20in%20HTML%2C%20use%20the%20style%20attribute,center%2C%20left%20and%20right%20alignment.
// https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_global_class2
?>
@extends('layouts.app')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Post New Affinity Group') }}</div>

                <div class="card-body">
                    <form method="POST" action= "{{ route('groups.index') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="groupTitle" class="col-md-4 col-form-label text-md-right">{{ __('Group Title') }}</label>

                            <div class="col-md-6">
                                <input id="groupTitle" type="text" class="form-control @error('groupTitle') is-invalid @enderror" name="groupTitle" value="{{ old('groupTitle') }}" required autocomplete="groupTitle" autofocus>

                                @error('groupTitle')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="about" class="col-md-4 col-form-label text-md-right">{{ __('About') }}</label>

                            <div class="col-md-6">
                                <input id="about" type="text" class="form-control @error('about') is-invalid @enderror" name="about" value="{{ old('about') }}" required autocomplete="about">

                                @error('about')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="rules" class="col-md-4 col-form-label text-md-right">{{ __('Rules') }}</label>

                            <div class="col-md-6">
                                <input id="rules" type="text" class="form-control @error('rules') is-invalid @enderror" name="rules" required autocomplete="rules">

                                @error('rules')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Post Group') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
