<html>
	<input type="file" name="image">
</html>